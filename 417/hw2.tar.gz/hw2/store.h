#ifndef STORE_H
#define STORE_H

const map <string, string> get_names (string file_name);

#endif // STORE_H
